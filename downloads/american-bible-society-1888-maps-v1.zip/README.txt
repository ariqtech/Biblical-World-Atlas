AMERICAN BIBLE SOCIETY STUDY-BIBLE MAPS (1888)
Biblical World Atlas research packet • Version 1

Extract the ZIP and open any JPEG in an image viewer. The eight files are the original JPEG reproductions supplied by GodWeb. No installation is needed. The catalog supplies source links, dimensions, Scripture references, and SHA-256 checksums for the JPEGs.

Publisher: American Bible Society, 1888.
Digitizing host and collection: https://www.godweb.org/maps/bmap00.htm
Rights: Public domain as identified by the digitizing host, GodWeb, for the American Bible Society plates published in 1888.

These plates are historical interpretations of geography, routes, and boundaries. Their depictions should be compared with modern historical and geographical evidence. This packet contains no modern survey data or Bible text.
